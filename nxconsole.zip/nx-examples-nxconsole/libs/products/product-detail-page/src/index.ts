export * from './lib/products-product-detail-page.module';
