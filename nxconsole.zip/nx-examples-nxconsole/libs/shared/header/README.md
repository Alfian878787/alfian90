# shared-header

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test shared-header` to execute the unit tests via [Jest](https://jestjs.io).
