export const getHeader = () => cy.get('nx-example-header');
