export * from './lib/shared-product-data';
