export * from './lib/product-data.mock';
