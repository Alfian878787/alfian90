export * from './lib/product-price/product-price.element';
