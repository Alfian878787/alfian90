export * from './lib/+state/products.reducer';
export * from './lib/+state/products.selectors';
export * from './lib/shared-product-state.module';
