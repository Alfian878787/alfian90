import 'jest-preset-angular';

import 'document-register-element';
