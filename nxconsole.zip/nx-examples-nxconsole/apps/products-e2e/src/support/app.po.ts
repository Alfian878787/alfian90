export const getPage = () => cy.get('nx-example-root');
