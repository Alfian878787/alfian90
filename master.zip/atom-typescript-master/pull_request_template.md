- [ ] All compiled assets are included (atom packages are git tags and hence the built files need to be a part of the source control)

